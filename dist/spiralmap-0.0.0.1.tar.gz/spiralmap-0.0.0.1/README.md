# SpiralMap
A Python library of the major spiral arm models of the Milky Way
# Acknowledging SpiralMap
If you make use of this package, please cite (), as well as the particular spiral models used. A BibTex file with the relevant citations is provided under 'datafiles'.

@software{spiralmap,  
  author = {Prusty, Abhay Kumar and Khanna, Shourya},  
  title = {SpiralMap: A Python library of the Milky Way's spiral structure},  
  year = {2025},  
  publisher = {GitHub},  
  url = {[https://github.com/Abhaypru/SpiralMapping_package](https://github.com/Abhaypru/SpiralMapping_package)}  
}  
